<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","","phonegaptest") or die ("could not connect database");
 //$con = mysqli_connect("localhost","sitefdv7_develop","techno@123","sitefdv7_phonegap") or die ("could not connect database");
 ?>
